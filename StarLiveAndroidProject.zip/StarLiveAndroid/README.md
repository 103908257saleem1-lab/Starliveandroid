# StarLive Android Studio Project

This project packages the StarLive HTML prototype as a native Android application using a WebView.

## Open in Android Studio
1. Open Android Studio.
2. Choose **Open** and select this `StarLiveAndroid` folder.
3. Let Gradle sync and install the required Android SDK/plugin components if Android Studio asks.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press **Run** to install the app.
6. To make an APK: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.

The debug APK will normally be under:
`app/build/outputs/apk/debug/app-debug.apk`

## Current scope
- StarLive UI packaged as an Android app.
- Live-room UI, calls UI, virtual diamond wallet, gifts, profile, and Lucky 28 demo are included from the HTML prototype.
- This build does **not** implement real-money deposits/withdrawals, cash redemption, regulated gambling, KYC/AML, or a production live-video backend.
- The diamond balances are demo/virtual credits.

## Production work still needed
- Backend/API and database
- Real authentication and account security
- Production live-video/voice infrastructure
- Moderation/reporting/blocking
- Notifications and analytics
- Store compliance
- Legal/licensing review before any real-money gambling or cash-out feature
